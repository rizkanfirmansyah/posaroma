<?php
	@session_start();

	include('sambung.php');
	
?>
