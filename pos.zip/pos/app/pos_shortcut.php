<tr>
	<td colspan="1" valign="top"><b>Keterangan Shortcut : </b><br>
		
		F1 = Form Baru <br>
		F2 = ke kolom barang <br>
		F3 = bayar <br>
		F4 = ke Kolom Member <br>
		F5 = ke kolom voucher <br>                                                                                          
	</td>
	
	<td colspan="1" valign="top">
		<br>
		<b>&raquo;Tambah/kurangi QTY detail paling atas (misalnya:  2/ ) </b><br>
                                        &nbsp;&nbsp;&nbsp;2 : qty <br>
                                        &nbsp;&nbsp;&nbsp;/ : eksekusi <br>
                                        
		<b>&raquo;Hapus detail barang sesuai dengan baris yg diinginkan (misalnya: 3=x ) </b><br>
                                                   &nbsp;&nbsp;&nbsp;3 : baris ketiga <br>
                                                   &nbsp;&nbsp;&nbsp;= : tanda <br>
                                                   &nbsp;&nbsp;&nbsp;x : eksekusi hapus <br>
                                                   
		<b>&raquo;Tambah/kurangi QTY detail sesuai baris yg diinginkan (misalnya: 4=3d ) </b><br>
                                                   &nbsp;&nbsp;&nbsp;4 : baris keempat <br>
                                                   &nbsp;&nbsp;&nbsp;= : tanda <br>
                                                   &nbsp;&nbsp;&nbsp;3 : qty 3 <br>
                                                   &nbsp;&nbsp;&nbsp;d : eksekusi 
	</td>
	
	<td>
		
	</td>
</tr>